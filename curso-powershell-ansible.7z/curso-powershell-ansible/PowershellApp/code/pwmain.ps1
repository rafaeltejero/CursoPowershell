#/**
#* ... Powershell App...
#*/


# Parámetros de entrada
[CmdletBinding()]
Param(
    [Parameter(Mandatory = $False, Position = 1)]
    [String]$exeMode = "c",
    [Parameter(Mandatory = $False, Position = 2)]
    [String]$package
)

# Averiguamos directorio base
$scriptFile = $myInvocation.MyCommand.Definition
$arrPartsScriptFile = $scriptFile.Split("\")

$global:scriptName = (($arrPartsScriptFile[$arrPartsScriptFile.Length - 1]).Split("."))[0]
$global:baseDir = (get-item $scriptFile).Directory.Parent.FullName
$global:exeMode = $exeMode

. "$global:baseDir\code\functions.ps1"


StartScript

Function ExecExternal {
    param (
        [string]$exe, 
        [string]$arguments
    )

    $process = New-Object -TypeName System.Diagnostics.Process
    $process.StartInfo.FileName = $exe
    $process.StartInfo.Arguments = $arguments
    
    $process.StartInfo.UseShellExecute = $false
    $process.StartInfo.RedirectStandardOutput = $true
    $process.StartInfo.RedirectStandardError = $true
    $process.Start()
    
    $output = $process.StandardOutput.ReadToEnd()   
    $err = $process.StandardError.ReadToEnd()
    
    $process.WaitForExit()
    
    $output
    $err
}

function InstallChocolatey() {
    # install chocolatey for current user
    $env:ChocolateyInstall='C:\ProgramData\chocoportable'

    if (-Not (Test-Path $env:ChocolateyInstall)) {
        # download and save installation script, then check signature
        $url = 'https://chocolatey.org/install.ps1'
        $outPath = "$env:temp\installChocolatey.ps1"
        Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $outPath

        # test signature
        $result = Get-AuthenticodeSignature -FilePath $outPath
        if ($result.Status -ne 'Valid')
        {
            Write-Warning "Installation Script Damaged/Malware?"
            exit 1
        }

        Start-Process -FilePath powershell -Wait -ArgumentList "-noprofile -ExecutionPolicy Bypass -File ""$outPath""" 

        # clean up
        Remove-Item -Path $outPath
    }
}

InstallChocolatey

ExecExternal "$env:ChocolateyInstall\choco" "install $package"

StopScript
