#/**
#* ... Powershell App...
#*/

# Parámetros de entrada
[CmdletBinding()]
Param(
    [Parameter(Mandatory = $True, Position = 1)]
    [String]$exeMode,
    [Parameter(Mandatory = $False, Position = 2)]
    [String]$package    
)


# Averiguamos directorio base
$scriptFile = $myInvocation.MyCommand.Definition
$arrPartsScriptFile = $scriptFile.Split("\")

$global:scriptName = (($arrPartsScriptFile[$arrPartsScriptFile.Length - 1]).Split("."))[0]
$global:baseDir = (get-item $scriptFile).Directory.Parent.FullName
$global:exeMode = $exeMode

. "$global:baseDir\code\functions.ps1"

StartScript

Write-Host "Instalación de paquete, playbook"

StopScript