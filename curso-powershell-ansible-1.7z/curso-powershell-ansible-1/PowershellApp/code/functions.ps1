#/**
#* ... Common functions ...
#*/

$global:baseDateMain = Get-Date -Format yyyy-MM-dd_h-mm-ss
$global:logFile = "$global:baseDir\log\log-$global:baseDateMain-$global:scriptName.log"

#/*
#
#   Function: StartScript
#
#   Inicializa los elementos necesarios.
#
#   Parameters:
#
#      
#      
#
#   Returns:
#
#      
#
#*/

Function StartScript {
    # Cargamos el fichero de configuración
    $pathConfig = "$global:baseDir\config\confValues.json"
    if (-Not (Test-Path $pathConfig)) {
        Write-Host "Config file not exist"
        Exit(-1)
    }
    else {
        try {
            $global:configVal = (Get-Content $pathConfig) -join "`n" | ConvertFrom-Json
            Msg "Deb" "Ok $global:configVal"
        }
        catch {
            Write-host "Invalid config file"
            Msg "Err" "Invalid config file"        
            Exit(-1) 
        }
    }

    $global:Result = new-object psobject
    $global:Result | add-member noteproperty StartTime $global:baseDateMain
    $global:Result | add-member noteproperty Output @()
    $global:Result | add-member noteproperty Log @()

    $mode = $global:exeMode
    Msg "Deb" "Start Process mode $mode"
}

#/*
#
#   Function: StopScript
#
#   Finaliza los elementos necesarios.
#
#   Parameters:
#
#      
#      
#
#   Returns:
#
#      
#
#*/

Function StopScript {
    Msg "Deb" "Ending Process"
#    if ($global:exeMode -eq "c") {
    if ($global:exeMode -ne "c") {
        foreach($line in Get-Content $global:logFile) {
            $result.Log += $line.ToString()
        }
        $result | ConvertTo-Json
    }
}

#/*
#
#   Function: Msg
#
#   Write messages. Estos mensajes se registrarán en el log si se ha ejecutado Start-Transcript.
#
#   Parameters:
#
#      $Type - Tipo de mensaje Inf Información, War - Warning, Err - Error.
#      $Message - Mensaje a escribir.
#
#   Returns:
#
#      
#
#*/

Function Msg {
    param (
        [ValidateSet("Err", "War", "Deb", "Inf")][String]$type,
        [String]$logMessage
    )

    [DateTime]$eventTime = Get-Date

    $msgLine = "$eventTime - $Type - $logMessage"

    if ($global:exeMode -eq "c") {
        switch ($type) {
            "Err" {Write-Host $msgLine -ForegroundColor Red; break}
            "War" {Write-Host $msgLine -ForegroundColor Yellow; break}
            "Deb" { 
                if ($global:configVal.Debug) {
                    Write-Host $msgLine -ForegroundColor Blue
                }          
            }
            "Inf" {Write-Host $msgLine -ForegroundColor Green}
        }
    }

    if ($global:configVal.Debug) { 
        $msgLine >> $global:logFile
    }
}

#/*
#
#   Function: ExecExternal
#
#   Exec extenal program and capture ouput and error.
#
#   Parameters:
#
#      $exe - Path to executable.
#      $arguments - Arguments.
#
#   Returns:
#
#      Object with output and error
#
#*/

Function ExecExternal {
    param (
        [string]$exe, 
        [string]$arguments
    )

    $process = New-Object -TypeName System.Diagnostics.Process
    $process.StartInfo.FileName = $exe
    $process.StartInfo.Arguments = $arguments
    
    $process.StartInfo.UseShellExecute = $false
    $process.StartInfo.RedirectStandardOutput = $true
    $process.StartInfo.RedirectStandardError = $true
    $process.Start()
    
    $output = $process.StandardOutput.ReadToEnd()   
    $err = $process.StandardError.ReadToEnd()
    
    $process.WaitForExit()
    
    $output
    $err
}
    